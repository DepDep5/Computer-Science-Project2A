class CalculatorDriver{
    public static void main (String[] args) {
        Calculator cal;
        cal = new Calculator(1, 5, 6, 0, 0, 2, 3, 1, 1, 3, 2);
        cal.display();
    }
}