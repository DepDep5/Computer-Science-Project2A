class Calculator {
    double quadA; // For the first variable in the quadratic equation
    double quadB; // For the second variable in the quadratic equation
    double quadC; // For the third variable in the quadratic equation
    double X1; // For the first set of coordiantes in the calculation for slope and midpoint equation
    double X2;// For the second set of coordiantes in the calculation for slope and midpoint equation
    double Y1;// For the first set of coordiantes in the calculation for slope and midpoint equation
    double Y2;// For the second set of coordiantes in the calculation for slope and midpoint equation
    double sumStart;//The initial number for the summary calculation
    double sumAmount;// For the amount to increase the initial number by
    double geoStart;//The initial number for the geometric calculation
    double geoAmount;// For the amount to multiply the initial number by
    
    
    public Calculator(double qA, double qB, double qC, double x1, double y1, double x2, double y2, double sStart, double sAmount, double gStart, double gAmount) {
        quadA = qA;
        quadB = qB;
        quadC = qC;
        X1 = x1;
        X2 = x2;
        Y1 = y1;
        Y2 = y2;
        sumStart = sStart;
        sumAmount = sAmount;
        geoStart = gStart;
        geoAmount = gAmount;
    }
    //the main display
    public void display() {
        quadratic();
        slope();
        midpoint();
        arithmetic();
        geometric();
    }
    //equations for calculations
    double quadAnsPlus (double quadA, double quadB, double quadC) {
        return (-1*quadB + Math.sqrt(quadB*quadB - 4*quadA*quadC)) / (2 * quadA);
    }
    double quadAnsMinus(double quadA, double quadB, double quadC) {
        return (-1*quadB - Math.sqrt(quadB*quadB - 4*quadA*quadC)) / (2 * quadA);
    }
    double slopeAll(double X1, double Y1, double X2, double Y2) {
        return (Y2 - Y1) / (X2 - X1);
    }
    double midpointX(double X1, double X2) {
        return (X2 + X1)/2;
    }
    double midpointY(double Y1, double Y2) {
        return (Y2 + Y1)/2;
    }
    double sumAnswer(double sumStart, double sumAmount) { 
        return sumStart + sumStart + sumAmount + sumStart + 2 * sumAmount + sumStart + 3 * sumAmount + sumStart + 4 * sumAmount;
    }  
    double geoAnswer(double geoStart, double geoAmount) {
        return geoStart * (1 - Math.pow(geoAmount, 3))/(1 - geoAmount);
    }
    //the printouts for all the equations
    public void quadratic() {
        System.out.println("QUADRATIC EQUATION");
        System.out.println("The Solutions For " + quadA + "x^2 + " + quadB + "x + " + quadC + " are " + quadAnsMinus(quadA, quadB, quadC) +  " and " + quadAnsPlus(quadA, quadB, quadC));
        System.out.println();
        System.out.println();
        System.out.println();
    }
    public void slope() {
        System.out.println("SLOPE FORMULA");
        System.out.println("A line connecting the points (" + X1 + ", " + Y1 + ") / (" + X2 + ", " + Y2 + ") has a slope of " + slopeAll(X1, Y1, X2, Y2));
        System.out.println();
        System.out.println();
        System.out.println();
    }
    public void midpoint() {
        System.out.println("MIDPOINT FORMULA");
        System.out.println("The midpoint between (" + Y1 + ", " + X1 + ") and (" + Y2 + ", " + X2 + ") is (" + midpointX(X1, X2) + ", " + midpointY(Y1, Y2) + ")");
        System.out.println();
        System.out.println();
        System.out.println();
    }
    public void arithmetic() {
        System.out.println("SUM OF AN ARITHMETIC SERIES");
        System.out.println("The sum of the first 5 terms of an arithmetic series that starts with " + sumStart + " and increases by " + sumAmount + " is " + sumAnswer(sumStart, sumAmount));
        System.out.println();
        System.out.println();
        System.out.println();
    }
    public void geometric() {
        System.out.println("SUM OF A GEOMETRIC SERIES");
        System.out.println("The sum of the first 3 terms of a finite geometric series that starts with " + geoStart + " and increases by a rate of " + geoAmount + " is " + geoAnswer(geoStart, geoAmount));
        System.out.println();
        System.out.println();
        System.out.println();
    }
}